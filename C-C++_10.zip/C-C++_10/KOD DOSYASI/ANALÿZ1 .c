#include<stdio.h>
#define N 100000


 int min(int a,int b){
 	return (a <= b)? a : b;
 }
 
 int FibonacciArama(int dizi[], int x, int n){
 
 	int j;
 	int count=0; 
 	int fibo2=0; 
 	int fibo1=1; 
 	int fibo=fibo2+fibo1; 
 	
 	
 	while(fibo<n){
 		fibo2=fibo1;
 		fibo1=fibo;
 		fibo=fibo2+fibo1;
	 }
	 
	 int offset=-1;
	 
	 while(fibo >1){
	 	count=count +1;
	 
	 	int i=min (offset+fibo2,n-1);
	 
	 	if(dizi[i] < x){
	 		fibo=fibo1;
	 		fibo1=fibo2;
	 		fibo2=fibo-fibo1;
	 		offset=i;
		 }
		
		 else{
		 	if(dizi[i] >x){
		 		fibo=fibo2;
		 		fibo1=fibo1 - fibo2;
		 		fibo2= fibo - fibo1;
		 	}
		 
		 	else{
		 		printf("\n yapilan karsilastirma sayisi : %d",count);
		 		
				 return i;
			 }
			 }
		 }
	
		 if(fibo1 && dizi[offset+1]==x){
		 	count++;
		 	printf("\nyapilan karsilastirma sayisi : %d ",count);
		 	
			 return offset+1;
		 }
	
		 printf("\n yapilan karsilastirma sayisi: %d",count);
		
		 return -1;
	 }

 int main(void){
 	
 	int dizi[N],y[N],n,x,i,index;
 	printf("sayi dizisinin eleman sayisini giriniz: ");
 	scanf("%d",&n);

 	for(i=0;i<n;i++){
 		dizi[i]=i+1;
 	}
 	

    for(i=0;i<n;i++){
 	index= FibonacciArama(dizi, dizi[i], n)+1;
 	printf("\n");
 	if(index >0){
 		printf("aradiginiz sayi dizinin %d.elemanidir",index);
 		printf("\n");
 	}
 }
 
 	return 0;
 }
