//fibonacci arama algoritmas�
#include<stdio.h>
#define N 100000



 int min(int a,int b){
 	return (a <= b)? a : b;
 }
 // bu fonksiyon fibonacci arama fonksiyonudur
 //aarad�g�m�z say�y� buldugu taktirde index'ini bulmazsa offset(-1) degerini bize d�nd�r�r
 int FibonacciSearch(int dizi[], int x, int n){
 	//fibonacci say�lar�n�n olu�turulmas�:
 	int j;//s�radan bir de�i�ken
 	int count=0; //kar��la�t�rma say�s�
 	int fibo2=0; // fibonacci say�s�'2 �nceki'
 	int fibo1=1; // fibonacci sayisi'1 �nceki'
 	int fibo=fibo2+fibo1; //fibonacci sayisi
 	//fibS, n'den b�y�k veya n'ye e�it en k���k fibonacci say�s� olu�uyor
 	
 	while(fibo<n){
 		fibo2=fibo1;
 		fibo1=fibo;
 		fibo=fibo2+fibo1;
	 }
	 //offset'(-1'e e�itliyoruz)
	 int offset=-1;
	 /* incelenecek elemanlar oldu�u s�rece dizi(fiso2) ile x'i kar��la�t�r�yoruz
	 fibo 1'e e�it olunca fibo2, 0 oluyor. */
	 while(fibo >1){
	 	count=count +1;
	 	//bakaca��m�z index'i belirlemek i�in min al�yoruz
	 	int i=min (offset+fibo2,n-1);
	 	//x,fibo2'deki de�erden b�y�kse altdiziyi offset ve 1 aras� alarak kes.
	 	if(dizi[i] < x){
	 		fibo=fibo1;
	 		fibo1=fibo2;
	 		fibo2=fibo-fibo1;
	 		offset=i;
		 }
		 //x, fibo2'deki de�erden k���kse altdiziyi i+1'den sonras� alarak kes
		 else{
		 	if(dizi[i] >x){
		 		fibo=fibo2;
		 		fibo1=fibo1 - fibo2;
		 		fibo2= fibo - fibo1;
		 	}
		 	//eleman bulundu
		 	else{
		 		printf("\n yapilan karsilastirma sayisi : %d",count);
		 	
				 return i;
			 }
			 }
		 }
		 //son eleman� x ile kar��la�t�r
		 if(fibo1 && dizi[offset+1]==x){
		 	count++;
		 	printf("\nyapilan karsilastirma sayisi : %d ",count);
		 	
			 return offset+1;
		 }
		 //eleman bulunamadi -1 d�nd�r�r
		 printf("\n yapilan karsilastirma sayisi: %d",count);
		 
		 return -1;
	 }
 //main fonksiyon
 int main(void){
 	
 	int dizi[N],y[N],n,x,i,index;
 	printf("sayi dizisinin eleman sayisini giriniz: ");
 	scanf("%d",&n);
 	printf("sirali dizinin elamanlarini giriniz:");
 	for(i=0;i<n;i++){
 		scanf("%d",&dizi[i]);
 	}
 	
 	printf("aradiginiz sayiyi giriniz: \n");
 	scanf("%d",&x);
 	index= FibonacciSearch(dizi, x, n)+1;
 	printf("\n");
 	if(index >0){
 		printf("aradiginiz sayi dizinin %d.elemanidir",index);
 	}
 	else{
 		printf("aradiginiz sayi dizide bulunmadi.");
 	}
 	return 0;
 }
	 
	 
	 
 
